import { bus } from '../core/EventBus.js';

// All sound is synthesized via Web Audio oscillators/noise rather than
// loaded audio files — zero asset weight, zero licensing concerns, and it
// sidesteps browser autoplay restrictions cleanly (context starts on the
// first user gesture, per spec below).
export class AudioEngine {
  constructor(){
    this.ctx = null;
    this.master = null;
    this.muted = false;
    this._ambientStarted = false;

    const resume = () => { this._ensureContext(); window.removeEventListener('pointerdown', resume); };
    window.addEventListener('pointerdown', resume);

    bus.on('mode:changed', () => this._blip());
    bus.on('sunrise:advance-start', () => this._chime(660, 'up'));
    bus.on('sunset:delay-start', () => this._chime(440, 'down'));
  }

  _ensureContext(){
    if (this.ctx) return;
    this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.5;
    this.master.connect(this.ctx.destination);
    this._startAmbient();
  }

  // Slow, detuned dual-oscillator pad through a lowpass filter — a quiet
  // "observatory hum" bed that sits under everything else.
  _startAmbient(){
    if (this._ambientStarted) return;
    this._ambientStarted = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 500;
    filter.connect(this.master);

    const ambientGain = this.ctx.createGain();
    ambientGain.gain.value = 0.06;
    ambientGain.connect(filter);

    [110, 110.5].forEach((freq) => {
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = freq;
      osc.connect(ambientGain);
      osc.start();
    });

    // Slow LFO breathing the filter cutoff for a living, non-static drone.
    const lfo = this.ctx.createOscillator();
    lfo.frequency.value = 0.05;
    const lfoGain = this.ctx.createGain();
    lfoGain.gain.value = 150;
    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    lfo.start();
  }

  // Short UI feedback tick on mode/nav changes.
  _blip(){
    if (!this.ctx || this.muted) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.value = 520;
    gain.gain.value = 0.0001;
    osc.connect(gain).connect(this.master);
    const t = this.ctx.currentTime;
    gain.gain.exponentialRampToValueAtTime(0.12, t + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
    osc.start(t);
    osc.stop(t + 0.14);
  }

  // Rising/falling chime for the sunrise-advance / sunset-delay teaching
  // moments — a soft two-note bell whose direction matches the physics.
  _chime(baseFreq, direction){
    if (!this.ctx || this.muted) return;
    const t = this.ctx.currentTime;
    const secondFreq = direction === 'up' ? baseFreq * 1.5 : baseFreq * 0.75;

    [ [baseFreq, 0], [secondFreq, 0.15] ].forEach(([freq, delay]) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.value = 0.0001;
      osc.connect(gain).connect(this.master);
      const start = t + delay;
      gain.gain.exponentialRampToValueAtTime(0.18, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.9);
      osc.start(start);
      osc.stop(start + 1.0);
    });
  }

  setMasterVolume(v){
    if (this.master) this.master.gain.value = v;
  }

  toggleMute(){
    this.muted = !this.muted;
    if (this.master) this.master.gain.value = this.muted ? 0 : 0.5;
    return this.muted;
  }

  dispose(){
    this.ctx?.close();
  }
}
