import { bus } from '../core/EventBus.js';

// Symmetric counterpart to Sunrise: the Sun has already geometrically
// dropped below the horizon (trueAlt < 0) but is still visible because
// refraction holds its image up above the true horizon (apparentAlt >= 0).
// Sky tinting is already handled by Sunrise's altitude-based color ramp
// (skyColorForAltitude applies identically whether the Sun is rising or
// setting), so this module only needs to detect the falling-edge event.
export class Sunset {
  constructor(){
    this._prevTrueAlt = null;
    this._delayActive = false;

    this._unsubRefraction = bus.on('refraction:state', (state) => this._onRefractionState(state));
  }

  _onRefractionState({ trueAltDeg, apparentAltDeg, deltaDeg }){
    const setting = this._prevTrueAlt !== null && trueAltDeg < this._prevTrueAlt;
    this._prevTrueAlt = trueAltDeg;

    const isDelayed = setting && trueAltDeg < 0 && apparentAltDeg >= 0;

    if (isDelayed && !this._delayActive){
      this._delayActive = true;
      bus.emit('sunset:delay-start', {
        trueAltDeg, apparentAltDeg, deltaDeg,
        message: `The Sun has already dropped ${Math.abs(trueAltDeg).toFixed(2)}° below the true horizon, but refraction keeps its image ${(deltaDeg * 60).toFixed(1)}\u2032 above it — sunset is delayed by what you're seeing right now.`,
      });
    } else if (!isDelayed && this._delayActive && setting){
      this._delayActive = false;
      bus.emit('sunset:delay-end', { trueAltDeg, apparentAltDeg });
    }
  }

  dispose(){
    this._unsubRefraction();
  }
}
