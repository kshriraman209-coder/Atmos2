import * as THREE from 'three';
import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';
import { clamp, rad2deg } from '../core/utils.js';

// Sun position is parameterized purely by time-of-day (0-24h) orbiting Earth
// in the equatorial plane. Reference observer sits at Earth's surface point
// (radius, 0, 0) with "up" = +X — this is the fixed point later systems
// (Refraction, Twinkling, Sunrise/Sunset) treat as "the observer" until the
// Observer system (module 13+) adds latitude/longitude selection.
const REFERENCE_OBSERVER_UP = new THREE.Vector3(1, 0, 0);

export class Sun {
  constructor(scene, { earthGroup, atmosphere } = {}){
    this.scene = scene;
    this.atmosphere = atmosphere;
    this.distance = CONFIG.scale.sunDistance;
    this.timeOfDay = CONFIG.defaults.timeOfDay_hr;
    this.autoPlay = false;
    this.autoPlaySpeed_hrPerSec = 0.05;

    // Visible sun disc — emissive, unlit, always faces camera by symmetry.
    const geometry = new THREE.SphereGeometry(CONFIG.scale.earthRadius * 1.6, 48, 48);
    const material = new THREE.MeshBasicMaterial({ color: 0xfff4d6 });
    this.mesh = new THREE.Mesh(geometry, material);
    scene.add(this.mesh);

    // Primary directional light standing in for solar illumination.
    this.light = new THREE.DirectionalLight(0xffffff, 2.2);
    scene.add(this.light);
    this.light.target.position.set(0, 0, 0);
    scene.add(this.light.target);

    this._unsubTick = bus.on('render:tick', ({ delta }) => this._onTick(delta));
    this._unsubParams = bus.on('params:timeOfDay', (hr) => this.setTimeOfDay(hr));

    this._applyPosition(); // initialize at default time
  }

  setTimeOfDay(hr){
    this.timeOfDay = ((hr % 24) + 24) % 24;
    this._applyPosition();
  }

  setAutoPlay(enabled){
    this.autoPlay = enabled;
  }

  _onTick(delta){
    if (this.autoPlay){
      this.timeOfDay = (this.timeOfDay + this.autoPlaySpeed_hrPerSec * delta) % 24;
    }
    this._applyPosition();
  }

  _applyPosition(){
    // Map 0-24h to a full revolution; 6h = sunrise at reference observer,
    // 18h = sunset, 12h = zenith-ish (equatorial simplification).
    const angle = ((this.timeOfDay / 24) * Math.PI * 2) - Math.PI / 2;

    const dir = new THREE.Vector3(Math.cos(angle), Math.sin(angle) * 0.35, Math.sin(angle));
    dir.normalize();

    this.mesh.position.copy(dir).multiplyScalar(this.distance);
    this.light.position.copy(this.mesh.position);
    this.light.target.position.set(0, 0, 0);

    // True geometric altitude at the reference observer (no refraction) —
    // the Refraction Physics module (module 8) will derive "apparent"
    // altitude from this true value and feed both into the HUD.
    const trueAltitudeDeg = rad2deg(Math.asin(clamp(dir.dot(REFERENCE_OBSERVER_UP), -1, 1)));

    // Warm the light near the horizon; dim it below it.
    const altitude01 = clamp((trueAltitudeDeg + 10) / 30, 0, 1);
    this.light.intensity = 0.4 + altitude01 * 1.8;
    this.light.color.setHSL(0.13 - altitude01 * 0.06, 0.6, 0.55 + altitude01 * 0.25);

    if (this.atmosphere) this.atmosphere.setSunDirection(dir);

    bus.emit('sun:state', { timeOfDay: this.timeOfDay, direction: dir, trueAltitudeDeg });
  }

  dispose(){
    this._unsubTick();
    this._unsubParams();
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
  }
}
