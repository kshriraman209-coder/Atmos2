import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';

const STORAGE_KEY = 'atmosObs:save:v1';
const AUTOSAVE_DEBOUNCE_MS = 800;

const DEFAULT_DATA = () => ({
  sliders: {
    density: CONFIG.defaults.atmosphericDensity,
    temperature: CONFIG.defaults.temperature_C,
    pressure: CONFIG.defaults.pressure_kPa,
    humidity: CONFIG.defaults.humidity_pct,
    observerHeight: CONFIG.defaults.observerHeight_m,
    timeOfDay: CONFIG.defaults.timeOfDay_hr,
  },
  quiz: { bestScore: 0, bestPct: 0, attempts: 0 },
  challenge: { bestScored: 0, attempts: 0 },
  lastMode: null,
});

export class SaveManager {
  constructor(controlPanel){
    this.controlPanel = controlPanel;
    this.data = this._load();
    this._saveTimer = null;

    this._restoreOnBoot();

    bus.on('params:atmosphere', (p) => this._patchSliders(p));
    bus.on('params:pressure', (v) => this._patchSliders({ pressure: v }));
    bus.on('params:observerHeight', (v) => this._patchSliders({ observerHeight: v }));
    bus.on('params:timeOfDay', (v) => this._patchSliders({ timeOfDay: v }));
    bus.on('mode:changed', (mode) => { this.data.lastMode = mode; this._scheduleSave(); });

    bus.on('quiz:completed', ({ score, pct }) => {
      this.data.quiz.attempts++;
      this.data.quiz.bestScore = Math.max(this.data.quiz.bestScore, score);
      this.data.quiz.bestPct = Math.max(this.data.quiz.bestPct, pct);
      this._saveNow();
    });

    bus.on('challenge:session-complete', ({ scored }) => {
      this.data.challenge.attempts++;
      this.data.challenge.bestScored = Math.max(this.data.challenge.bestScored, scored);
      this._saveNow();
    });
  }

  // Replays saved slider values onto the live systems exactly once at boot,
  // then syncs the ControlPanel's visual slider positions to match — the
  // panel itself stays the single source of truth for future user input.
  _restoreOnBoot(){
    const { sliders } = this.data;
    bus.emit('params:atmosphere', { density: sliders.density, temperature: sliders.temperature, humidity: sliders.humidity });
    bus.emit('params:pressure', sliders.pressure);
    bus.emit('params:observerHeight', sliders.observerHeight);
    bus.emit('params:timeOfDay', sliders.timeOfDay);
    this.controlPanel?.applyValues(sliders);
  }

  _patchSliders(partial){
    Object.assign(this.data.sliders, partial);
    this._scheduleSave();
  }

  _scheduleSave(){
    clearTimeout(this._saveTimer);
    this._saveTimer = setTimeout(() => this._saveNow(), AUTOSAVE_DEBOUNCE_MS);
  }

  _saveNow(){
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.data));
    } catch (err) {
      console.warn('[SaveManager] Unable to persist progress:', err);
    }
  }

  _load(){
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return DEFAULT_DATA();
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_DATA(), ...parsed, sliders: { ...DEFAULT_DATA().sliders, ...parsed.sliders } };
    } catch (err) {
      console.warn('[SaveManager] Corrupt save data, resetting:', err);
      return DEFAULT_DATA();
    }
  }

  clearProgress(){
    localStorage.removeItem(STORAGE_KEY);
    this.data = DEFAULT_DATA();
  }
}
