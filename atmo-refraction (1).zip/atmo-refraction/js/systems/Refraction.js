import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';
import { clamp, deg2rad } from '../core/utils.js';

// Converts the Sun's true geometric altitude into its apparent (refracted)
// altitude using Bennett's atmospheric refraction approximation, corrected
// for pressure, temperature, and a density slider that lets the user
// exaggerate/dampen the effect beyond real Earth conditions. This is the
// NCERT "why the sun is visible before it geometrically rises" mechanism.

// Bennett (1982): R(arcmin) = 1.02 / tan( h + 10.3/(h+5.11) ), h in degrees.
// Valid smoothly down to the horizon and slightly below.
function bennettRefractionArcmin(trueAltDeg){
  const hClamped = Math.max(trueAltDeg, -1.9); // formula breaks down further below horizon
  const denom = Math.tan(deg2rad(hClamped + 10.3 / (hClamped + 5.11)));
  return 1.02 / denom;
}

export class Refraction {
  constructor(){
    this.params = {
      density: CONFIG.defaults.atmosphericDensity,
      temperature: CONFIG.defaults.temperature_C,
      pressure: CONFIG.defaults.pressure_kPa,
      humidity: CONFIG.defaults.humidity_pct,
      observerHeight: CONFIG.defaults.observerHeight_m,
    };

    this.el = {
      trueAlt: document.getElementById('hud-true-alt'),
      apparentAlt: document.getElementById('hud-apparent-alt'),
      delta: document.getElementById('hud-delta'),
      extension: document.getElementById('hud-extension'),
    };

    this._lastTrueAlt = 0;

    this._unsubSun = bus.on('sun:state', ({ trueAltitudeDeg }) => this._recompute(trueAltitudeDeg));
    this._unsubAtmo = bus.on('params:atmosphere', (p) => this._updateParams(p));
    this._unsubHeight = bus.on('params:observerHeight', (h) => this._updateParams({ observerHeight: h }));
    this._unsubPressure = bus.on('params:pressure', (p) => this._updateParams({ pressure: p }));
  }

  _updateParams(partial){
    Object.assign(this.params, partial);
    this._recompute(this._lastTrueAlt);
  }

  _recompute(trueAltDeg){
    this._lastTrueAlt = trueAltDeg;
    const { density, temperature, pressure, humidity, observerHeight } = this.params;

    // Standard meteorological correction (pressure/temperature), applied to
    // the base Bennett value, then scaled by the user-controlled density
    // slider so "thicker air" visibly bends light more.
    const pressureTempFactor = (pressure / 101.0) * (283 / (273 + temperature));
    const humidityFactor = 1 + (humidity / 100) * 0.05; // water vapor mildly raises refractive index
    // Observer height thins the air column above; refraction weakens slightly with altitude.
    const heightFactor = clamp(1 - observerHeight / 9000, 0.5, 1);

    const baseArcmin = bennettRefractionArcmin(trueAltDeg);
    const deltaArcmin = Math.max(0, baseArcmin * density * pressureTempFactor * humidityFactor * heightFactor);
    const deltaDeg = deltaArcmin / 60;

    const apparentAltDeg = trueAltDeg + deltaDeg;

    // Sun crosses ~15°/hour; convert the horizon-level bend into how much
    // earlier the sunrise / later the sunset appears, in minutes.
    const extensionMinutesPerEvent = deltaDeg * 4; // deg / (15deg/60min)
    const totalExtensionMinutes = extensionMinutesPerEvent * 2; // sunrise advance + sunset delay

    this._updateHUD(trueAltDeg, apparentAltDeg, deltaArcmin, totalExtensionMinutes);

    bus.emit('refraction:state', {
      trueAltDeg, apparentAltDeg, deltaArcmin, deltaDeg,
      extensionMinutesPerEvent, totalExtensionMinutes,
    });
  }

  _updateHUD(trueAlt, apparentAlt, deltaArcmin, totalExtensionMinutes){
    this.el.trueAlt.textContent = `${trueAlt.toFixed(2)}°`;
    this.el.apparentAlt.textContent = `${apparentAlt.toFixed(2)}°`;
    this.el.delta.textContent = `${deltaArcmin.toFixed(1)}′`;
    this.el.extension.textContent = `${totalExtensionMinutes.toFixed(1)} min`;
  }

  dispose(){
    this._unsubSun();
    this._unsubAtmo();
    this._unsubHeight();
    this._unsubPressure();
  }
}
