import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';
import { clamp, deg2rad } from '../core/utils.js';

// Real scintillation model: starlight is a point source, so it threads
// through many small, randomly-moving turbulent air cells on its way down.
// Each cell acts as a weak, shifting lens — the light path bends by a
// different tiny random amount moment to moment, so brightness flickers.
// Planets are visually broad discs (many light paths average together per
// point on the retina), so the fluctuations cancel out — they don't twinkle.
// This module only computes/broadcasts amplitude+frequency; Stars.js applies it.

export class Twinkling {
  constructor(stars){
    this.stars = stars;

    this.params = {
      density: CONFIG.defaults.atmosphericDensity,
      temperature: CONFIG.defaults.temperature_C,
      humidity: CONFIG.defaults.humidity_pct,
      observerHeight: CONFIG.defaults.observerHeight_m,
    };
    this.sunAltitudeDeg = 45; // used only as a proxy for "how much sky is dark/turbulent right now" via time-of-day context

    this._unsubAtmo = bus.on('params:atmosphere', (p) => this._updateParams(p));
    this._unsubHeight = bus.on('params:observerHeight', (h) => this._updateParams({ observerHeight: h }));
    this._unsubSun = bus.on('sun:state', ({ trueAltitudeDeg }) => { this.sunAltitudeDeg = trueAltitudeDeg; this._recompute(); });

    this._recompute();
  }

  _updateParams(partial){
    Object.assign(this.params, partial);
    this._recompute();
  }

  _recompute(){
    const { density, temperature, humidity, observerHeight } = this.params;

    // Turbulence strength: denser, warmer (more convective), humid air near
    // the ground mixes more violently. Standard temperature (15°C) is the
    // calibration point; deviation either way increases convective mixing.
    const tempDeviation = Math.abs(temperature - 15) / 25; // 0 at standard, ~1 at extremes
    const densityFactor = clamp((density - 0.4) / 1.4, 0, 1);
    const humidityFactor = humidity / 100;
    const turbulence = clamp(0.25 * densityFactor + 0.45 * tempDeviation + 0.30 * humidityFactor, 0, 1);

    // Higher observers look through a thinner, calmer air column.
    const heightRelief = clamp(1 - observerHeight / 6000, 0.3, 1);

    // Airmass: light near the horizon travels a much longer path through
    // turbulent lower atmosphere than light overhead — classic reason stars
    // twinkle more near the horizon than at zenith.
    const altRad = deg2rad(clamp(this.sunAltitudeDeg, 2, 90));
    const airmass = clamp(1 / Math.sin(altRad), 1, 6) / 6; // normalized 0-1

    const combined = clamp(turbulence * heightRelief * (0.5 + 0.5 * airmass), 0, 1);

    const amplitude = 0.05 + combined * 0.55;      // brightness flicker depth
    const frequencyScale = 0.6 + combined * 2.2;   // faster flicker in rougher air

    this.stars.setTwinkleIntensity(amplitude);
    this.stars.setTwinkleFrequencyScale(frequencyScale);

    bus.emit('twinkle:state', { turbulence: combined, amplitude, frequencyScale });
  }

  dispose(){
    this._unsubAtmo();
    this._unsubHeight();
    this._unsubSun();
  }
}
