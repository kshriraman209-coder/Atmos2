import * as THREE from 'three';
import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';
import { clamp } from '../core/utils.js';

// Fresnel-rim glow shell around Earth. Reacts live to atmospheric density,
// humidity, and temperature uniforms — these are the same physical inputs
// the refraction physics module (module 8) will drive from the UI sliders.
// Sun direction is exposed for the Sun system to tint the limb at sunset.

const VERTEX_SHADER = /* glsl */ `
  varying vec3 vNormal;
  varying vec3 vWorldPos;

  void main(){
    vNormal = normalize(normalMatrix * normal);
    vec4 worldPos = modelMatrix * vec4(position, 1.0);
    vWorldPos = worldPos.xyz;
    gl_Position = projectionMatrix * viewMatrix * worldPos;
  }
`;

const FRAGMENT_SHADER = /* glsl */ `
  uniform vec3 uCameraPos;
  uniform vec3 uSunDirection;
  uniform float uDensity;      // 0.4 - 1.8, relative to standard atmosphere
  uniform float uHumidity;     // 0 - 100 %
  uniform float uTemperature;  // Celsius, shifts scattering tint slightly

  varying vec3 vNormal;
  varying vec3 vWorldPos;

  void main(){
    vec3 viewDir = normalize(uCameraPos - vWorldPos);
    float rim = 1.0 - max(dot(viewDir, vNormal), 0.0);
    rim = pow(rim, 2.2);

    // Base sky colors: thin/dry -> cyan, dense/humid -> warmer haze.
    vec3 clearSky = vec3(0.35, 0.75, 1.0);
    vec3 hazySky  = vec3(0.95, 0.65, 0.35);
    float haziness = clamp((uDensity - 0.4) / 1.4 * 0.6 + uHumidity / 100.0 * 0.4, 0.0, 1.0);
    vec3 skyColor = mix(clearSky, hazySky, haziness);

    // Sunset/sunrise limb tint: glow warms when the sun sits near the horizon
    // as seen from the glow shell's silhouette edge.
    float sunFacing = clamp(dot(vNormal, uSunDirection), -1.0, 1.0);
    float horizonGlow = 1.0 - abs(sunFacing);
    vec3 warmEdge = vec3(1.0, 0.45, 0.15);
    skyColor = mix(skyColor, warmEdge, horizonGlow * 0.5 * step(0.0, sunFacing + 0.3));

    float density01 = clamp((uDensity - 0.4) / 1.4, 0.0, 1.0);
    float alpha = rim * (0.35 + density01 * 0.5);

    gl_FragColor = vec4(skyColor, alpha);
  }
`;

export class Atmosphere {
  constructor(earthGroup){
    this.radius = CONFIG.scale.earthRadius + CONFIG.scale.atmosphereThickness;

    this.uniforms = {
      uCameraPos:    { value: new THREE.Vector3() },
      uSunDirection: { value: new THREE.Vector3(1, 0, 0) },
      uDensity:      { value: CONFIG.defaults.atmosphericDensity },
      uHumidity:     { value: CONFIG.defaults.humidity_pct },
      uTemperature:  { value: CONFIG.defaults.temperature_C },
    };

    const geometry = new THREE.SphereGeometry(this.radius, 96, 96);
    const material = new THREE.ShaderMaterial({
      vertexShader: VERTEX_SHADER,
      fragmentShader: FRAGMENT_SHADER,
      uniforms: this.uniforms,
      transparent: true,
      side: THREE.BackSide,      // render inner surface so rim glow reads from outside
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    this.mesh = new THREE.Mesh(geometry, material);
    // Attached to the tilted group but NOT to the rotating texture mesh —
    // the glow shell must stay tilt-locked, not spin with the planet surface.
    earthGroup.add(this.mesh);

    this._unsubTick = bus.on('render:tick', () => this._syncCamera());
    this._unsubParams = bus.on('params:atmosphere', (p) => this.setParameters(p));
  }

  _syncCamera(){
    // Camera world position is read each frame from the active THREE camera
    // via a global handle set by Renderer; fallback keeps shader stable.
    const cam = window.__app?.renderer?.camera;
    if (cam) this.uniforms.uCameraPos.value.copy(cam.position);
  }

  setParameters({ density, humidity, temperature } = {}){
    if (density !== undefined) this.uniforms.uDensity.value = clamp(density, 0.4, 1.8);
    if (humidity !== undefined) this.uniforms.uHumidity.value = clamp(humidity, 0, 100);
    if (temperature !== undefined) this.uniforms.uTemperature.value = temperature;
  }

  setSunDirection(dirVec3){
    this.uniforms.uSunDirection.value.copy(dirVec3).normalize();
  }

  dispose(){
    this._unsubTick();
    this._unsubParams();
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
  }
}
