import * as THREE from 'three';
import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';
import { makeRng } from '../core/utils.js';

// GPU point-sprite star field. Each star carries a random phase + base
// brightness + color-temperature attribute so the Twinkling system
// (module 9) can drive real atmospheric-scintillation math per-star
// without rebuilding geometry. A simple sine shimmer runs by default so
// the field isn't static before module 9 lands.

const VERTEX_SHADER = /* glsl */ `
  attribute float aSize;
  attribute float aPhase;
  attribute float aBrightness;
  attribute vec3 aColor;

  uniform float uTime;
  uniform float uTwinkleAmp;
  uniform float uFreqScale;

  varying float vAlpha;
  varying vec3 vColor;

  void main(){
    vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
    gl_Position = projectionMatrix * mvPosition;

    float shimmer = 1.0 + uTwinkleAmp * sin(uTime * uFreqScale * (3.0 + aPhase * 4.0) + aPhase * 6.2831);
    vAlpha = clamp(aBrightness * shimmer, 0.0, 1.0);
    vColor = aColor;

    // Perspective-attenuated point size so distant stars don't dominate.
    gl_PointSize = aSize * (300.0 / -mvPosition.z);
  }
`;

const FRAGMENT_SHADER = /* glsl */ `
  varying float vAlpha;
  varying vec3 vColor;

  void main(){
    vec2 uv = gl_PointCoord - vec2(0.5);
    float d = length(uv);
    float falloff = smoothstep(0.5, 0.0, d);
    gl_FragColor = vec4(vColor, vAlpha * falloff);
  }
`;

export class Stars {
  constructor(scene, seed = 42){
    this.count = CONFIG.render.starCount;
    this.radius = CONFIG.scale.starFieldRadius;
    const rng = makeRng(seed);

    const positions = new Float32Array(this.count * 3);
    const sizes = new Float32Array(this.count);
    const phases = new Float32Array(this.count);
    const brightness = new Float32Array(this.count);
    const colors = new Float32Array(this.count * 3);

    for (let i = 0; i < this.count; i++){
      // Uniform random point on a sphere shell (Marsaglia method).
      let x, y, s;
      do {
        x = rng() * 2 - 1; y = rng() * 2 - 1;
        s = x * x + y * y;
      } while (s >= 1);
      const factor = 2 * Math.sqrt(1 - s);
      const z = 1 - 2 * s;
      const sx = x * factor, sy = y * factor;

      positions[i * 3]     = sx * this.radius;
      positions[i * 3 + 1] = sy * this.radius;
      positions[i * 3 + 2] = z * this.radius;

      sizes[i] = 1.0 + rng() * 2.4;
      phases[i] = rng();
      brightness[i] = 0.35 + rng() * 0.65;

      // Star color temperature: mostly white, some blue-hot and red-cool.
      const temp = rng();
      const c = new THREE.Color();
      if (temp < 0.15) c.setRGB(0.75, 0.82, 1.0);       // blue-white
      else if (temp > 0.85) c.setRGB(1.0, 0.78, 0.65);  // warm red-orange
      else c.setRGB(1.0, 1.0, 0.96);                    // neutral white
      colors[i * 3] = c.r; colors[i * 3 + 1] = c.g; colors[i * 3 + 2] = c.b;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));
    geometry.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
    geometry.setAttribute('aBrightness', new THREE.BufferAttribute(brightness, 1));
    geometry.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));

    this.uniforms = {
      uTime: { value: 0 },
      uTwinkleAmp: { value: 0.18 }, // subtle default; module 9 replaces with real scintillation model
      uFreqScale: { value: 1.0 },
    };

    const material = new THREE.ShaderMaterial({
      vertexShader: VERTEX_SHADER,
      fragmentShader: FRAGMENT_SHADER,
      uniforms: this.uniforms,
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });

    this.points = new THREE.Points(geometry, material);
    scene.add(this.points);

    this._unsubTick = bus.on('render:tick', ({ elapsed }) => {
      this.uniforms.uTime.value = elapsed;
    });
  }

  setTwinkleIntensity(amount){
    this.uniforms.uTwinkleAmp.value = amount;
  }

  setTwinkleFrequencyScale(scale){
    this.uniforms.uFreqScale.value = scale;
  }

  dispose(){
    this._unsubTick();
    this.points.geometry.dispose();
    this.points.material.dispose();
  }
}
