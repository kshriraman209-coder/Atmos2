import { bus } from '../core/EventBus.js';

// Watches Renderer's FPS stream (emitted every ~0.5s) and steps quality
// up or down through three tiers. Hysteresis (two consecutive bad/good
// samples before switching) prevents visible flicker from single-frame
// spikes — e.g. one texture load stall shouldn't drop the whole scene
// to low quality and immediately snap back.

const TIERS = {
  high:   { pixelRatioCap: 2,   starFraction: 1.0,  label: 'HIGH' },
  medium: { pixelRatioCap: 1.5, starFraction: 0.6,  label: 'MEDIUM' },
  low:    { pixelRatioCap: 1,   starFraction: 0.35, label: 'LOW' },
};
const TIER_ORDER = ['low', 'medium', 'high'];

export class PerformanceMonitor {
  constructor(renderer, stars){
    this.renderer = renderer;
    this.stars = stars;
    this.tierIndex = TIER_ORDER.indexOf('high'); // start optimistic
    this._badStreak = 0;
    this._goodStreak = 0;

    this.perfEl = document.getElementById('hud-perf');

    this._unsub = bus.on('render:fps', (fps) => this._onFps(fps));
    this._applyTier(); // ensure initial state is consistent
  }

  _onFps(fps){
    if (this.perfEl) this.perfEl.textContent = `${fps} FPS \u00b7 ${TIERS[TIER_ORDER[this.tierIndex]].label}`;

    if (fps < 45){
      this._badStreak++;
      this._goodStreak = 0;
      if (this._badStreak >= 2 && this.tierIndex > 0){
        this.tierIndex--;
        this._badStreak = 0;
        this._applyTier();
      }
    } else if (fps > 55){
      this._goodStreak++;
      this._badStreak = 0;
      if (this._goodStreak >= 4 && this.tierIndex < TIER_ORDER.length - 1){
        this.tierIndex++;
        this._goodStreak = 0;
        this._applyTier();
      }
    } else {
      this._badStreak = 0;
      this._goodStreak = 0;
    }
  }

  _applyTier(){
    const tier = TIERS[TIER_ORDER[this.tierIndex]];

    const targetPixelRatio = Math.min(window.devicePixelRatio, tier.pixelRatioCap);
    this.renderer.renderer.setPixelRatio(targetPixelRatio);

    const drawCount = Math.floor(this.stars.count * tier.starFraction);
    this.stars.points.geometry.setDrawRange(0, drawCount);

    bus.emit('performance:tier-changed', { tier: TIER_ORDER[this.tierIndex] });
  }

  dispose(){
    this._unsub();
  }
}
