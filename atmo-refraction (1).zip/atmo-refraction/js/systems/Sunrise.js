import * as THREE from 'three';
import { bus } from '../core/EventBus.js';
import { clamp } from '../core/utils.js';

// Maps apparent solar altitude to a sky color. Exported so the Sunset
// module (next) can reuse the exact same dusk/dawn palette instead of
// duplicating a second color ramp.
const NIGHT    = new THREE.Color(0x05070d);
const TWILIGHT = new THREE.Color(0x2a3f6b);
const DAWN     = new THREE.Color(0xff8c42);
const DAY      = new THREE.Color(0x4fc3f7).lerp(new THREE.Color(0x0a1420), 0.55);

export function skyColorForAltitude(apparentAltDeg){
  const t1 = clamp((apparentAltDeg + 10) / 8, 0, 1);   // night -> twilight, -10° to -2°
  const t2 = clamp((apparentAltDeg + 2) / 4, 0, 1);    // twilight -> dawn, -2° to +2°
  const t3 = clamp((apparentAltDeg - 2) / 10, 0, 1);   // dawn -> full day, +2° to +12°

  const c = NIGHT.clone().lerp(TWILIGHT, t1);
  c.lerp(DAWN, t2 * (1 - t3));
  c.lerp(DAY, t3);
  return c;
}

// Detects the specific NCERT teaching moment: the Sun is still geometrically
// below the horizon (trueAlt < 0) but already visible because refraction
// bent its light over the horizon (apparentAlt >= 0) — "advanced sunrise".
export class Sunrise {
  constructor(scene){
    this.scene = scene;
    this._prevTrueAlt = null;
    this._advanceActive = false;

    this._unsubRefraction = bus.on('refraction:state', (state) => this._onRefractionState(state));
  }

  _onRefractionState({ trueAltDeg, apparentAltDeg, deltaDeg }){
    const rising = this._prevTrueAlt !== null && trueAltDeg > this._prevTrueAlt;
    this._prevTrueAlt = trueAltDeg;

    // Live sky tint — always kept current regardless of rising/setting,
    // so the horizon reads correctly the instant the app loads.
    this.scene.background = skyColorForAltitude(apparentAltDeg);

    const isAdvanced = rising && trueAltDeg < 0 && apparentAltDeg >= 0;

    if (isAdvanced && !this._advanceActive){
      this._advanceActive = true;
      bus.emit('sunrise:advance-start', {
        trueAltDeg, apparentAltDeg, deltaDeg,
        message: `The Sun is still ${Math.abs(trueAltDeg).toFixed(2)}° below the true horizon, but refraction bends its light up by ${(deltaDeg * 60).toFixed(1)}\u2032 — you're seeing an image of a sun that hasn't geometrically risen yet.`,
      });
    } else if (!isAdvanced && this._advanceActive && rising){
      this._advanceActive = false;
      bus.emit('sunrise:advance-end', { trueAltDeg, apparentAltDeg });
    }
  }

  dispose(){
    this._unsubRefraction();
  }
}
