import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';

// One OrbitControls instance, reconfigured per mode rather than swapped out —
// avoids re-registering DOM listeners on every mode change. Simulate mode
// locks the view to a horizon-watching sweep (the natural framing for
// refraction/sunrise/sunset demos); Explore mode opens full free orbit.

const OBSERVER_SURFACE_POINT = new THREE.Vector3(CONFIG.scale.earthRadius, 0, 0);

export class CameraController {
  constructor(renderer){
    this.renderer = renderer;
    this.controls = new OrbitControls(renderer.camera, renderer.canvas);
    this.controls.enableDamping = true;
    this.controls.dampingFactor = 0.08;
    this.controls.minDistance = CONFIG.scale.earthRadius * 1.3;
    this.controls.maxDistance = CONFIG.scale.starFieldRadius * 0.9;

    this._unsubMode = bus.on('mode:changed', (mode) => this._applyModeFraming(mode));
    this._unsubTick = bus.on('render:tick', () => this.controls.update());

    this._applyModeFraming('learn'); // sensible default before any explicit mode click
  }

  _applyModeFraming(mode){
    if (mode === 'simulate'){
      this._frameHorizonView();
    } else if (mode === 'explore'){
      this._frameFreeOrbit();
    } else {
      // Learn / Challenge / Quiz: gentle default orbit around Earth, full
      // rotation but no zoom-through, so scripted camera moves (later
      // modules) aren't fighting a fully-locked control scheme.
      this.controls.target.set(0, 0, 0);
      this.controls.minPolarAngle = 0;
      this.controls.maxPolarAngle = Math.PI;
      this.controls.minAzimuthAngle = -Infinity;
      this.controls.maxAzimuthAngle = Infinity;
      this.controls.minDistance = CONFIG.scale.earthRadius * 1.3;
      this.controls.maxDistance = CONFIG.scale.starFieldRadius * 0.9;
      this.controls.enablePan = false;
    }
    this.controls.update();
  }

  // Positions and constrains the camera to stand just above the reference
  // observer's surface point, looking toward the horizon in front of them —
  // the same point Sun.js uses as its refraction reference.
  _frameHorizonView(){
    const standHeight = 1.6 * (CONFIG.scale.earthRadius / 10); // scaled human height
    const outward = OBSERVER_SURFACE_POINT.clone().normalize();

    const eye = OBSERVER_SURFACE_POINT.clone().add(outward.clone().multiplyScalar(standHeight));
    this.renderer.camera.position.copy(eye);

    const lookTarget = eye.clone().add(new THREE.Vector3(0, 0, -1).multiplyScalar(CONFIG.scale.earthRadius));
    this.controls.target.copy(lookTarget);

    // Constrain orbit to a modest sweep around the horizon — enough to look
    // up toward the sun's arc and side to side, not enough to spin through the planet.
    this.controls.minDistance = 0.5;
    this.controls.maxDistance = CONFIG.scale.earthRadius * 0.5;
    this.controls.minPolarAngle = Math.PI * 0.25;
    this.controls.maxPolarAngle = Math.PI * 0.75;
    this.controls.enablePan = false;
  }

  _frameFreeOrbit(){
    this.controls.target.set(0, 0, 0);
    this.renderer.camera.position.set(0, CONFIG.scale.earthRadius * 1.8, CONFIG.scale.earthRadius * 4.2);
    this.controls.minDistance = CONFIG.scale.earthRadius * 1.3;
    this.controls.maxDistance = CONFIG.scale.starFieldRadius * 0.9;
    this.controls.minPolarAngle = 0;
    this.controls.maxPolarAngle = Math.PI;
    this.controls.enablePan = true;
  }

  dispose(){
    this._unsubMode();
    this._unsubTick();
    this.controls.dispose();
  }
}
