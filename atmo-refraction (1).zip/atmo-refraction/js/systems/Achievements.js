import { bus } from '../core/EventBus.js';

const STORAGE_KEY = 'atmosObs:achievements:v1';

const ACHIEVEMENTS = [
  { id: 'first-quiz', title: 'First Steps', description: 'Complete your first quiz.' },
  { id: 'quiz-master', title: 'Quiz Master', description: 'Score 100% on the quiz.' },
  { id: 'light-bender', title: 'Light Bender', description: 'Push refraction \u0394 above 40\u2032 in Challenge Mode.' },
  { id: 'sky-stirrer', title: 'Sky Stirrer', description: 'Push atmospheric turbulence above 70%.' },
  { id: 'sunrise-catcher', title: 'Sunrise Catcher', description: 'Witness an advanced sunrise \u2014 the Sun visible before it truly rises.' },
  { id: 'sunset-catcher', title: 'Sunset Catcher', description: 'Witness a delayed sunset \u2014 the Sun lingering after it has truly set.' },
  { id: 'challenge-champion', title: 'Challenge Champion', description: 'Clear every Challenge Mode task in one session.' },
  { id: 'explorer', title: 'Explorer', description: 'Enter Free Explore mode.' },
];

// Every achievement here maps to an event this build already emits —
// no new instrumentation was needed in any prior module.
export class Achievements {
  constructor(){
    this.unlocked = this._load();
    this._toastQueue = [];
    this._toastBusy = false;

    bus.on('quiz:completed', ({ pct }) => {
      this._unlock('first-quiz');
      if (pct >= 100) this._unlock('quiz-master');
    });

    bus.on('challenge:completed', ({ id, success }) => {
      if (!success) return;
      if (id === 'delta-40') this._unlock('light-bender');
      if (id === 'turbulence-70') this._unlock('sky-stirrer');
    });

    bus.on('challenge:session-complete', ({ scored, total }) => {
      if (scored === total) this._unlock('challenge-champion');
    });

    bus.on('sunrise:advance-start', () => this._unlock('sunrise-catcher'));
    bus.on('sunset:delay-start', () => this._unlock('sunset-catcher'));
    bus.on('mode:changed', (mode) => { if (mode === 'explore') this._unlock('explorer'); });
  }

  _unlock(id){
    if (this.unlocked.includes(id)) return;
    this.unlocked.push(id);
    this._save();

    const meta = ACHIEVEMENTS.find(a => a.id === id);
    bus.emit('achievement:unlocked', meta);
    this._queueToast(meta);
  }

  _queueToast(meta){
    this._toastQueue.push(meta);
    if (!this._toastBusy) this._drainToasts();
  }

  _drainToasts(){
    const meta = this._toastQueue.shift();
    if (!meta){ this._toastBusy = false; return; }
    this._toastBusy = true;

    const toast = document.createElement('div');
    toast.className = 'achievement-toast';
    toast.innerHTML = `
      <div class="achievement-toast-badge">\u2605</div>
      <div>
        <div class="achievement-toast-title">${meta.title}</div>
        <div class="achievement-toast-desc">${meta.description}</div>
      </div>
    `;
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('shown'));

    setTimeout(() => {
      toast.classList.remove('shown');
      setTimeout(() => { toast.remove(); this._drainToasts(); }, 300);
    }, 3200);
  }

  getProgress(){
    return { unlocked: this.unlocked.length, total: ACHIEVEMENTS.length };
  }

  _load(){
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    } catch {
      return [];
    }
  }

  _save(){
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.unlocked));
    } catch (err) {
      console.warn('[Achievements] Unable to persist:', err);
    }
  }
}
