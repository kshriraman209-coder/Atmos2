import * as THREE from 'three';
import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';

// Planets sit closer than the star shell and are lit/shaded normally —
// this is the visual proof behind "planets don't twinkle": they render as
// steady, extended discs reflecting sunlight, not point sources refracted
// by turbulent air cells (that contrast is made explicit in Learn Mode,
// module 15). Sizes are relative-scaled off Earth's radius, not to-scale
// distances (real distances would push them off-screen).

const PLANET_DATA = [
  { name: 'Mercury', relRadius: 0.38, orbitRadius: 140, orbitPeriodSec: 90,  color: 0xa9a394,
    texture: 'https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/planets/mercurymap.jpg' },
  { name: 'Venus',   relRadius: 0.95, orbitRadius: 190, orbitPeriodSec: 140, color: 0xe8cfa0,
    texture: 'https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/planets/venusmap.jpg' },
  { name: 'Mars',    relRadius: 0.53, orbitRadius: 260, orbitPeriodSec: 170, color: 0xb35f42,
    texture: 'https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/planets/marsmap1k.jpg' },
  { name: 'Jupiter', relRadius: 2.6,  orbitRadius: 340, orbitPeriodSec: 260, color: 0xd8c9a8,
    texture: null }, // procedural-shaded, no external texture dependency
];

export class Planets {
  constructor(scene){
    this.scene = scene;
    this.group = new THREE.Group();
    scene.add(this.group);

    this.planets = PLANET_DATA.map((data, i) => this._createPlanet(data, i));

    this._unsubTick = bus.on('render:tick', ({ delta }) => this._onTick(delta));
  }

  _createPlanet(data, index){
    const radius = CONFIG.scale.earthRadius * data.relRadius;
    const geometry = new THREE.SphereGeometry(radius, 48, 48);
    const material = new THREE.MeshStandardMaterial({
      color: data.color,
      roughness: 0.9,
      metalness: 0.05,
    });

    if (data.texture){
      new THREE.TextureLoader().load(data.texture, (tex) => {
        tex.colorSpace = THREE.SRGBColorSpace;
        material.map = tex;
        material.needsUpdate = true;
      });
    }

    const mesh = new THREE.Mesh(geometry, material);
    const pivot = new THREE.Group();
    // Stagger orbital inclination slightly per planet so they don't share
    // one flat plane — reads as a real solar-system arrangement, not a ring.
    pivot.rotation.x = (index % 2 === 0 ? 1 : -1) * (0.05 + index * 0.02);
    pivot.add(mesh);
    this.group.add(pivot);

    mesh.position.set(data.orbitRadius, 0, 0);

    return {
      ...data,
      mesh,
      pivot,
      spinSpeed: (Math.PI * 2) / (18 + index * 6), // self-rotation, varies per planet
      orbitAngle: (index / PLANET_DATA.length) * Math.PI * 2,
    };
  }

  _onTick(delta){
    this.planets.forEach((p) => {
      p.orbitAngle += (Math.PI * 2 / p.orbitPeriodSec) * delta;
      p.mesh.position.set(
        Math.cos(p.orbitAngle) * p.orbitRadius,
        0,
        Math.sin(p.orbitAngle) * p.orbitRadius
      );
      p.mesh.rotation.y += p.spinSpeed * delta;
    });
  }

  dispose(){
    this._unsubTick();
    this.planets.forEach((p) => {
      p.mesh.geometry.dispose();
      p.mesh.material.dispose();
    });
  }
}
