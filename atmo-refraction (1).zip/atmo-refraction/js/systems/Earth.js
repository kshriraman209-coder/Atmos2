import * as THREE from 'three';
import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';

const TEXTURE_URL = 'https://raw.githubusercontent.com/mrdoob/three.js/dev/examples/textures/planets/earth_atmos_2048.jpg';
const AXIAL_TILT_DEG = 23.5;
const ROTATION_PERIOD_SEC = 40; // stylized day length for visual pacing, not real-time

// Earth mesh with realistic texture, correct axial tilt, and continuous
// rotation. Exposes .group so Atmosphere/observer-marker systems can
// attach as children and inherit rotation/tilt automatically.
export class Earth {
  constructor(scene){
    this.radius = CONFIG.scale.earthRadius;

    this.group = new THREE.Group();
    this.group.rotation.z = THREE.MathUtils.degToRad(AXIAL_TILT_DEG);
    scene.add(this.group);

    const geometry = new THREE.SphereGeometry(this.radius, 96, 96);
    const material = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.85,
      metalness: 0.0,
    });

    this.mesh = new THREE.Mesh(geometry, material);
    this.group.add(this.mesh);

    this._loadTexture(material);
    this._addBaseLighting(scene);

    this._unsubscribe = bus.on('render:tick', ({ delta }) => this._onTick(delta));
  }

  _loadTexture(material){
    const loader = new THREE.TextureLoader();
    loader.load(TEXTURE_URL, (tex) => {
      tex.colorSpace = THREE.SRGBColorSpace;
      material.map = tex;
      material.needsUpdate = true;
    });
  }

  // Minimal illumination so the sphere is visible before the Sun system
  // (module 5) installs the real directional sunlight and shadows.
  _addBaseLighting(scene){
    this.ambient = new THREE.AmbientLight(0x304050, 0.9);
    this.fill = new THREE.DirectionalLight(0xffffff, 1.4);
    this.fill.position.set(1, 0.4, 1);
    scene.add(this.ambient, this.fill);
  }

  _onTick(delta){
    const angularSpeed = (Math.PI * 2) / ROTATION_PERIOD_SEC;
    this.mesh.rotation.y += angularSpeed * delta;
  }

  dispose(){
    this._unsubscribe();
    this.mesh.geometry.dispose();
    this.mesh.material.dispose();
  }
}
