import { App } from './core/App.js';
import { bus } from './core/EventBus.js';

const app = new App();
window.__app = app; // dev/debug handle, set early so systems constructed during boot can use it

app.boot([
  { label: 'Loading configuration…', task: async () => { await new Promise(r => setTimeout(r, 120)); } },
  { label: 'Preparing interface…', task: async () => { await new Promise(r => setTimeout(r, 150)); } },
]).catch((err) => {
  // Without this, any thrown error during boot leaves the progress bar
  // stuck forever with zero feedback — this is almost certainly why you're
  // seeing a blank/stuck screen. Check the browser console (F12) for the
  // full stack; this overlay shows the short version.
  console.error('[AtmosObs] Boot failed:', err);
  const status = document.getElementById('boot-status');
  if (status){
    status.textContent = `Boot failed: ${err.message}. Open DevTools console (F12) for details.`;
    status.style.color = '#e05555';
  }
});

bus.on('app:ready', () => console.log('[AtmosObs] shell ready'));

// Watchdog: if boot hasn't completed in a reasonable time, something is
// hung (usually a blocked CDN fetch or running from file:// instead of a
// local server) rather than genuinely still loading — surface that instead
// of leaving the bar frozen with no explanation.
let bootFinished = false;
bus.on('app:ready', () => { bootFinished = true; });
setTimeout(() => {
  if (bootFinished) return;
  const status = document.getElementById('boot-status');
  if (status && !status.dataset.errored){
    status.dataset.errored = '1';
    status.textContent = 'Still loading after 8s — check your connection, or that this page is served over http:// (not file://). Open DevTools console (F12) for the exact error.';
    status.style.color = '#e05555';
  }
}, 8000);
