// Central config: physical constants, scaling, and default sim state.
// All modules read from here — never hardcode magic numbers elsewhere.

export const CONFIG = {
  scale: {
    earthRadius: 10,          // scene units
    atmosphereThickness: 1.2, // scene units (exaggerated for visibility)
    sunDistance: 400,
    starFieldRadius: 900,
  },
  physics: {
    seaLevelPressure_kPa: 101.325,
    seaLevelTemp_C: 15,
    lapseRate_CPerKm: 6.5,       // troposphere temperature lapse
    refractionAtHorizon_arcmin: 34, // standard horizon refraction (NCERT: ~34')
    scintillationBaseFreq_Hz: 6,
  },
  defaults: {
    atmosphericDensity: 1.0,   // relative to standard, 0.4–1.8
    temperature_C: 15,
    pressure_kPa: 101.325,
    humidity_pct: 50,
    observerHeight_m: 0,
    timeOfDay_hr: 6.0,         // 0–24
  },
  render: {
    targetFPS: 60,
    starCount: 6000,
    planetCount: 4,
  },
};

export const MODES = ['learn', 'simulate', 'explore', 'challenge', 'quiz'];
