import { bus } from '../core/EventBus.js';

// NCERT Class 10 "Atmospheric Refraction" question bank. Each question
// carries its own explanation so the reveal doubles as a micro Learn-Mode
// moment. Scoring emits 'quiz:completed' for the Achievement system (later
// module) to consume — no coupling needed here beyond that one event.

const QUESTIONS = [
  {
    q: 'Why does the atmosphere refract starlight?',
    options: [
      'Because the atmosphere is uniform in density',
      'Because the atmosphere is a medium of gradually varying (non-uniform) refractive index',
      'Because stars emit bent light',
      'Because the atmosphere absorbs starlight',
    ],
    correct: 1,
    explanation: 'The atmosphere\u2019s density \u2014 and hence refractive index \u2014 decreases with altitude, so light continuously bends as it descends. This gradual, non-uniform medium is the entire cause of atmospheric refraction.',
  },
  {
    q: 'Why do stars twinkle but planets do not?',
    options: [
      'Planets are farther away than stars',
      'Stars are point sources; planets are extended sources, so their light-path fluctuations average out',
      'Planets emit their own steady light',
      'Stars move faster across the sky',
    ],
    correct: 1,
    explanation: 'A star is effectively a point source, so its single light path is highly sensitive to turbulent air cells. A planet is a broad disc \u2014 many slightly different paths reach your eye at once, and their fluctuations cancel out.',
  },
  {
    q: 'Roughly how much earlier does refraction make the Sun appear to rise?',
    options: ['About 2 minutes', 'About 20 minutes', 'About 2 hours', 'No effect on sunrise'],
    correct: 0,
    explanation: 'Standard horizon refraction is about 34\u2032 (arcminutes). At the Sun\u2019s ~15\u00b0/hour apparent motion, that translates to roughly 2 minutes of earlier sunrise.',
  },
  {
    q: 'Where is atmospheric refraction strongest?',
    options: ['Directly overhead (zenith)', 'Near the horizon', 'It is the same everywhere', 'Only at noon'],
    correct: 1,
    explanation: 'Light from near the horizon travels the longest path through the densest, lowest layers of atmosphere, so it bends the most. Overhead light barely bends at all.',
  },
  {
    q: 'A star\u2019s apparent position due to refraction is:',
    options: [
      'Lower than its actual (true) position',
      'Higher than its actual (true) position',
      'Exactly the same as its true position',
      'To the side of its true position',
    ],
    correct: 1,
    explanation: 'Refraction bends starlight toward the normal as it enters denser air, which shifts the star\u2019s apparent position higher in the sky than its true geometric position.',
  },
  {
    q: 'What mainly causes the moment-to-moment brightness flicker in twinkling?',
    options: [
      'The star\u2019s own light output changing rapidly',
      'Continuously changing atmospheric refractive conditions along the light path',
      'Clouds passing in front of stars',
      'The rotation of the Earth',
    ],
    correct: 1,
    explanation: 'Turbulent pockets of air with slightly different temperatures/densities constantly shift, changing the refraction along the star\u2019s light path from moment to moment \u2014 that\u2019s the twinkle.',
  },
  {
    q: 'Sunset appears delayed due to refraction because:',
    options: [
      'The Sun physically slows down near the horizon',
      'The Sun\u2019s image remains visible above the horizon briefly after it has geometrically set',
      'Refraction has no effect at sunset, only sunrise',
      'The atmosphere blocks the Sun completely at sunset',
    ],
    correct: 1,
    explanation: 'Just as with sunrise, refraction keeps bending the Sun\u2019s light over the horizon even after the Sun has geometrically dropped below it \u2014 so we keep seeing it a little longer.',
  },
  {
    q: 'If atmospheric density were suddenly uniform throughout (no gradient), what would happen to twinkling and horizon refraction?',
    options: [
      'Both would increase',
      'Both would vanish \u2014 no gradient means no bending',
      'Twinkling would increase, refraction would vanish',
      'Nothing would change',
    ],
    correct: 1,
    explanation: 'Refraction \u2014 and its byproduct, twinkling \u2014 depends entirely on the atmosphere having a changing (non-uniform) refractive index. Remove the gradient, and light travels straight through with no bending at all.',
  },
];

export class Quiz {
  constructor(container){
    this.container = container;
    this.index = 0;
    this.score = 0;
    this.answered = false;

    this.el = document.createElement('div');
    this.el.className = 'quiz-panel hidden';
    this.container.appendChild(this.el);

    this._unsubMode = bus.on('mode:changed', (mode) => {
      this.el.classList.toggle('hidden', mode !== 'quiz');
      if (mode === 'quiz') this._reset();
    });
  }

  _reset(){
    this.index = 0;
    this.score = 0;
    this.answered = false;
    this._render();
  }

  _render(){
    if (this.index >= QUESTIONS.length){
      this._renderResults();
      return;
    }

    const item = QUESTIONS[this.index];
    this.answered = false;

    this.el.innerHTML = `
      <div class="quiz-progress">QUESTION ${this.index + 1} / ${QUESTIONS.length}</div>
      <div class="quiz-question">${item.q}</div>
      <div class="quiz-options">
        ${item.options.map((opt, i) => `<button class="quiz-option" data-i="${i}">${opt}</button>`).join('')}
      </div>
      <div class="quiz-explanation hidden" id="quiz-explanation"></div>
      <button class="quiz-next hidden" id="quiz-next">Next \u2192</button>
    `;

    this.el.querySelectorAll('.quiz-option').forEach((btn) => {
      btn.addEventListener('click', () => this._onAnswer(parseInt(btn.dataset.i, 10), item));
    });
    this.el.querySelector('#quiz-next').addEventListener('click', () => {
      this.index++;
      this._render();
    });
  }

  _onAnswer(selectedIndex, item){
    if (this.answered) return;
    this.answered = true;

    const buttons = this.el.querySelectorAll('.quiz-option');
    buttons.forEach((btn, i) => {
      btn.disabled = true;
      if (i === item.correct) btn.classList.add('correct');
      else if (i === selectedIndex) btn.classList.add('incorrect');
    });

    if (selectedIndex === item.correct) this.score++;

    const explanationEl = this.el.querySelector('#quiz-explanation');
    explanationEl.textContent = item.explanation;
    explanationEl.classList.remove('hidden');
    this.el.querySelector('#quiz-next').classList.remove('hidden');
  }

  _renderResults(){
    const pct = Math.round((this.score / QUESTIONS.length) * 100);
    this.el.innerHTML = `
      <div class="quiz-results">
        <div class="quiz-score">${this.score} / ${QUESTIONS.length}</div>
        <div class="quiz-score-label">${pct}% correct</div>
        <button class="quiz-next" id="quiz-restart">Retake Quiz</button>
      </div>
    `;
    this.el.querySelector('#quiz-restart').addEventListener('click', () => this._reset());

    bus.emit('quiz:completed', { score: this.score, total: QUESTIONS.length, pct });
  }

  dispose(){
    this._unsubMode();
    this.el.remove();
  }
}
