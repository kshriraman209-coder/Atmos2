import { bus } from '../core/EventBus.js';
import { CONFIG } from '../data/config.js';

// Every slider here emits exactly the events Refraction, Atmosphere, Sun,
// and Twinkling already subscribe to — no new wiring needed in those
// systems. Visible only in Simulate/Explore modes; hidden for Learn/
// Challenge/Quiz, which control the scene programmatically instead.

const SLIDERS = [
  { key: 'density', label: 'ATMOSPHERIC DENSITY', min: 0.4, max: 1.8, step: 0.01,
    default: CONFIG.defaults.atmosphericDensity, unit: '\u00d7', channel: 'params:atmosphere', field: 'density' },
  { key: 'temperature', label: 'TEMPERATURE', min: -20, max: 45, step: 0.5,
    default: CONFIG.defaults.temperature_C, unit: '\u00b0C', channel: 'params:atmosphere', field: 'temperature' },
  { key: 'pressure', label: 'PRESSURE', min: 85, max: 105, step: 0.1,
    default: CONFIG.defaults.pressure_kPa, unit: 'kPa', channel: 'params:pressure', field: null },
  { key: 'humidity', label: 'HUMIDITY', min: 0, max: 100, step: 1,
    default: CONFIG.defaults.humidity_pct, unit: '%', channel: 'params:atmosphere', field: 'humidity' },
  { key: 'observerHeight', label: 'OBSERVER HEIGHT', min: 0, max: 5000, step: 50,
    default: CONFIG.defaults.observerHeight_m, unit: 'm', channel: 'params:observerHeight', field: null },
  { key: 'timeOfDay', label: 'TIME OF DAY', min: 0, max: 24, step: 0.05,
    default: CONFIG.defaults.timeOfDay_hr, unit: 'h', channel: 'params:timeOfDay', field: null },
];

const VISIBLE_MODES = new Set(['simulate', 'explore']);

export class ControlPanel {
  constructor(container){
    this.container = container;

    this.el = document.createElement('div');
    this.el.className = 'control-panel hidden';
    this.el.innerHTML = `
      <div class="control-panel-title">ATMOSPHERIC CONTROLS</div>
      ${SLIDERS.map(s => this._rowTemplate(s)).join('')}
    `;
    this.container.appendChild(this.el);

    SLIDERS.forEach(s => this._wireSlider(s));

    this._unsubMode = bus.on('mode:changed', (mode) => {
      this.el.classList.toggle('hidden', !VISIBLE_MODES.has(mode));
    });
  }

  _rowTemplate(s){
    const formatted = s.step < 1 ? s.default.toFixed(2) : s.default;
    return `
      <div class="control-row">
        <div class="control-row-head">
          <span class="control-label">${s.label}</span>
          <span class="control-value" id="ctrl-val-${s.key}">${formatted}${s.unit}</span>
        </div>
        <input type="range" id="ctrl-${s.key}" min="${s.min}" max="${s.max}" step="${s.step}" value="${s.default}">
      </div>
    `;
  }

  _wireSlider(s){
    const input = this.el.querySelector(`#ctrl-${s.key}`);
    const valueEl = this.el.querySelector(`#ctrl-val-${s.key}`);

    input.addEventListener('input', () => {
      const raw = parseFloat(input.value);
      valueEl.textContent = `${s.step < 1 ? raw.toFixed(2) : raw}${s.unit}`;

      if (s.field){
        bus.emit(s.channel, { [s.field]: raw });
      } else {
        bus.emit(s.channel, raw);
      }
    });
  }

  // Restores slider positions/labels from saved data without re-emitting
  // params:* events — the caller (SaveManager) is responsible for emitting
  // the restored state once, after all values are applied.
  applyValues(values){
    SLIDERS.forEach((s) => {
      if (values[s.key] === undefined) return;
      const input = this.el.querySelector(`#ctrl-${s.key}`);
      const valueEl = this.el.querySelector(`#ctrl-val-${s.key}`);
      input.value = values[s.key];
      valueEl.textContent = `${s.step < 1 ? values[s.key].toFixed(2) : values[s.key]}${s.unit}`;
    });
  }

  dispose(){
    this._unsubMode();
    this.el.remove();
  }
}
