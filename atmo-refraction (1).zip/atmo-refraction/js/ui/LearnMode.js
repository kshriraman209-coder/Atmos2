import { bus } from '../core/EventBus.js';

// Static content pass through every topic in the mission brief. "Try it"
// jumps straight into Simulate mode with a suggested time-of-day so the
// concept just read about is immediately visible live.

const LESSONS = [
  {
    title: 'What Is Atmospheric Refraction?',
    body: 'Earth\u2019s atmosphere isn\u2019t one uniform slab of air \u2014 it gets thinner (less dense) the higher you go. Since a medium\u2019s refractive index depends on its density, light entering the atmosphere from space passes through a continuously changing medium and bends gradually, curving toward the denser air below. That gradual bending is atmospheric refraction.',
    tryTime: null,
  },
  {
    title: 'Twinkling of Stars',
    body: 'A star is so far away it behaves like a single point of light. As that light finally reaches you, it passes through pockets of air at slightly different temperatures and densities \u2014 each one bending it a little differently, moment to moment. The result: the star\u2019s apparent brightness and position flicker rapidly. That flicker is twinkling.',
    tryTime: null,
  },
  {
    title: 'Why Planets Don\u2019t Twinkle',
    body: 'Planets are much closer than stars, so they appear as tiny discs rather than points \u2014 many light rays from across that disc reach your eye at once. Each ray gets bent slightly differently by the turbulent air, but averaged across the whole disc, those fluctuations cancel out. A broad source can\u2019t flicker the way a point source does.',
    tryTime: null,
  },
  {
    title: 'Apparent Position of Stars',
    body: 'Refraction bends starlight toward the normal as it enters denser air near the ground, which shifts a star\u2019s apparent position higher than where it geometrically actually is. This is why astronomers must correct raw telescope readings for refraction before recording a star\u2019s true position.',
    tryTime: null,
  },
  {
    title: 'Advanced Sunrise',
    body: 'Near the horizon, sunlight travels through the thickest, densest slice of atmosphere \u2014 so it bends the most there, by roughly 34 arcminutes (about the Sun\u2019s own angular width). That\u2019s enough to make the Sun visible nearly 2 minutes before it has geometrically crossed the horizon.',
    tryTime: 5.9,
  },
  {
    title: 'Delayed Sunset',
    body: 'The same bending happens in reverse at day\u2019s end: even after the Sun has geometrically dropped below the horizon, refraction keeps bending its light up into your line of sight for a couple of extra minutes \u2014 delaying the moment it actually disappears from view.',
    tryTime: 18.1,
  },
  {
    title: 'Earth\u2019s Atmospheric Layers',
    body: 'The troposphere (lowest ~12 km) holds nearly 80% of the atmosphere\u2019s mass and almost all its weather \u2014 and it\u2019s where the density gradient driving refraction is steepest. Higher layers (stratosphere, mesosphere, and beyond) are progressively thinner and contribute far less to the bending you observe at the horizon.',
    tryTime: null,
  },
  {
    title: 'Try the Physics Yourself',
    body: 'Every slider in Simulate Mode \u2014 density, temperature, pressure, humidity, observer height, time of day \u2014 feeds directly into the same refraction model used in this lesson. Push density up, drop temperature down, and watch the HUD\u2019s refraction \u0394 and daylight extension respond in real time.',
    tryTime: null,
  },
];

export class LearnMode {
  constructor(container){
    this.container = container;
    this.index = 0;

    this.el = document.createElement('div');
    this.el.className = 'learn-panel hidden';
    this.container.appendChild(this.el);

    this._unsubMode = bus.on('mode:changed', (mode) => {
      this.el.classList.toggle('hidden', mode !== 'learn');
      if (mode === 'learn') this._render();
    });
  }

  _render(){
    const lesson = LESSONS[this.index];
    this.el.innerHTML = `
      <div class="learn-progress">LESSON ${this.index + 1} / ${LESSONS.length}</div>
      <div class="learn-title">${lesson.title}</div>
      <div class="learn-body">${lesson.body}</div>
      <div class="learn-actions">
        <button class="learn-nav" id="learn-prev" ${this.index === 0 ? 'disabled' : ''}>\u2190 Prev</button>
        ${lesson.tryTime !== null ? `<button class="learn-tryit" id="learn-tryit">Try It Live \u2192</button>` : ''}
        <button class="learn-nav" id="learn-next" ${this.index === LESSONS.length - 1 ? 'disabled' : ''}>Next \u2192</button>
      </div>
      <div class="learn-dots">
        ${LESSONS.map((_, i) => `<span class="learn-dot ${i === this.index ? 'active' : ''}"></span>`).join('')}
      </div>
    `;

    this.el.querySelector('#learn-prev')?.addEventListener('click', () => { this.index--; this._render(); });
    this.el.querySelector('#learn-next')?.addEventListener('click', () => { this.index++; this._render(); });
    this.el.querySelector('#learn-tryit')?.addEventListener('click', () => {
      bus.emit('params:timeOfDay', lesson.tryTime);
      // Routed through App's own setMode (not a raw bus emit) so nav
      // highlighting and currentMode tracking stay correct.
      window.__app?.setMode('simulate');
    });
  }

  dispose(){
    this._unsubMode();
    this.el.remove();
  }
}
