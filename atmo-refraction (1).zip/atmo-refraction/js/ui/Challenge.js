import { bus } from '../core/EventBus.js';

// Each challenge either checks a threshold against the latest live physics
// snapshot (refraction delta, daylight extension, turbulence) or waits for
// a one-shot event (advance-sunrise / delayed-sunset). Snapshot is kept
// current continuously via bus subscriptions, independent of UI state.

const CHALLENGES = [
  {
    id: 'delta-40',
    title: 'Bend the Light',
    hint: 'Raise atmospheric density and lower temperature until the refraction \u0394 exceeds 40\u2032.',
    timeLimitSec: 45,
    type: 'threshold',
    check: (snap) => snap.deltaArcmin >= 40,
    liveLabel: (snap) => `\u0394 = ${snap.deltaArcmin.toFixed(1)}\u2032 / 40\u2032 target`,
  },
  {
    id: 'extension-6',
    title: 'Stretch the Day',
    hint: 'Push total daylight extension above 6 minutes using density, temperature, and pressure together.',
    timeLimitSec: 45,
    type: 'threshold',
    check: (snap) => snap.totalExtensionMinutes >= 6,
    liveLabel: (snap) => `Extension = ${snap.totalExtensionMinutes.toFixed(1)} min / 6 min target`,
  },
  {
    id: 'turbulence-70',
    title: 'Stir the Sky',
    hint: 'Combine high humidity, extreme temperature, and high density to push turbulence above 70%.',
    timeLimitSec: 40,
    type: 'threshold',
    check: (snap) => snap.turbulence >= 0.7,
    liveLabel: (snap) => `Turbulence = ${Math.round(snap.turbulence * 100)}% / 70% target`,
  },
  {
    id: 'advance-sunrise',
    title: 'Catch the Advanced Sunrise',
    hint: 'Slide time-of-day toward sunrise (~6h) and raise density \u2014 catch the moment the Sun is visible before it truly rises.',
    timeLimitSec: 60,
    type: 'event',
    event: 'sunrise:advance-start',
  },
  {
    id: 'delayed-sunset',
    title: 'Catch the Delayed Sunset',
    hint: 'Slide time-of-day toward sunset (~18h) and raise density \u2014 catch the Sun lingering after true sunset.',
    timeLimitSec: 60,
    type: 'event',
    event: 'sunset:delay-start',
  },
];

export class Challenge {
  constructor(container){
    this.container = container;
    this.snapshot = { deltaArcmin: 0, totalExtensionMinutes: 0, turbulence: 0 };
    this.results = [];
    this.currentIndex = 0;
    this.timeRemaining = 0;
    this.active = false;

    this.el = document.createElement('div');
    this.el.className = 'challenge-panel hidden';
    this.container.appendChild(this.el);

    bus.on('refraction:state', (s) => {
      this.snapshot.deltaArcmin = s.deltaArcmin;
      this.snapshot.totalExtensionMinutes = s.totalExtensionMinutes;
    });
    bus.on('twinkle:state', (s) => { this.snapshot.turbulence = s.turbulence; });
    bus.on('sunrise:advance-start', () => this._onEventFired('sunrise:advance-start'));
    bus.on('sunset:delay-start', () => this._onEventFired('sunset:delay-start'));
    bus.on('render:tick', ({ delta }) => this._onTick(delta));

    this._unsubMode = bus.on('mode:changed', (mode) => {
      this.el.classList.toggle('hidden', mode !== 'challenge');
      if (mode === 'challenge') this._startSession();
      else this.active = false;
    });
  }

  _startSession(){
    this.currentIndex = 0;
    this.results = [];
    this._startChallenge();
  }

  _startChallenge(){
    const item = CHALLENGES[this.currentIndex];
    this.timeRemaining = item.timeLimitSec;
    this.active = true;
    this._render(item);
  }

  _onEventFired(eventName){
    const item = CHALLENGES[this.currentIndex];
    if (this.active && item.type === 'event' && item.event === eventName){
      this._complete(true, item);
    }
  }

  _onTick(delta){
    if (!this.active) return;
    const item = CHALLENGES[this.currentIndex];

    if (item.type === 'threshold' && item.check(this.snapshot)){
      this._complete(true, item);
      return;
    }

    this.timeRemaining -= delta;
    if (this.timeRemaining <= 0){
      this._complete(false, item);
      return;
    }

    this._updateLiveReadout(item);
  }

  _complete(success, item){
    this.active = false;
    this.results.push({ id: item.id, success });
    bus.emit('challenge:completed', { id: item.id, success, index: this.currentIndex });
    this._renderOutcome(item, success);
  }

  _render(item){
    this.el.innerHTML = `
      <div class="challenge-progress">CHALLENGE ${this.currentIndex + 1} / ${CHALLENGES.length}</div>
      <div class="challenge-title">${item.title}</div>
      <div class="challenge-hint">${item.hint}</div>
      <div class="challenge-live" id="challenge-live"></div>
      <div class="challenge-timerbar"><div class="challenge-timerfill" id="challenge-timerfill"></div></div>
    `;
    this._updateLiveReadout(item);
  }

  _updateLiveReadout(item){
    const liveEl = this.el.querySelector('#challenge-live');
    const fillEl = this.el.querySelector('#challenge-timerfill');
    if (liveEl) liveEl.textContent = item.type === 'threshold' ? item.liveLabel(this.snapshot) : 'Waiting for the moment to occur\u2026';
    if (fillEl) fillEl.style.width = `${Math.max(0, (this.timeRemaining / item.timeLimitSec) * 100)}%`;
  }

  _renderOutcome(item, success){
    const isLast = this.currentIndex === CHALLENGES.length - 1;
    const scored = this.results.filter(r => r.success).length;

    this.el.innerHTML = `
      <div class="challenge-outcome ${success ? 'success' : 'fail'}">${success ? 'Success!' : 'Time\u2019s up'}</div>
      <div class="challenge-score-line">Score so far: ${scored} / ${this.results.length}</div>
      <button class="quiz-next" id="challenge-continue">${isLast ? 'Finish' : 'Next Challenge \u2192'}</button>
    `;

    this.el.querySelector('#challenge-continue').addEventListener('click', () => {
      if (isLast){
        bus.emit('challenge:session-complete', { scored, total: CHALLENGES.length });
        this._startSession();
      } else {
        this.currentIndex++;
        this._startChallenge();
      }
    });
  }

  dispose(){
    this._unsubMode();
    this.el.remove();
  }
}
