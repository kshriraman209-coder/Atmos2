import * as THREE from 'three';
import { bus } from './EventBus.js';
import { CONFIG } from '../data/config.js';

// Owns the WebGL context and render loop. All visual systems (Earth, Sun,
// stars, planets) register themselves via scene.add() — this module never
// knows about scene contents, only about rendering them.
export class Renderer {
  constructor(canvas){
    this.canvas = canvas;
    this.clock = new THREE.Clock();
    this.running = false;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x05070d);

    this.camera = new THREE.PerspectiveCamera(
      50,
      window.innerWidth / window.innerHeight,
      0.1,
      CONFIG.scale.starFieldRadius * 2
    );
    this.camera.position.set(0, CONFIG.scale.earthRadius * 1.8, CONFIG.scale.earthRadius * 4.2);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this._resize();

    // FPS tracking for the performance system (module 18) to consume.
    this._frameCount = 0;
    this._fpsTimer = 0;
    this.fps = 60;

    window.addEventListener('resize', () => this._resize());
  }

  _resize(){
    const w = window.innerWidth;
    const h = window.innerHeight;
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
  }

  start(){
    if (this.running) return;
    this.running = true;
    this.clock.start();
    this._loop();
  }

  stop(){
    this.running = false;
  }

  _loop(){
    if (!this.running) return;
    requestAnimationFrame(() => this._loop());

    const delta = Math.min(this.clock.getDelta(), 0.1); // clamp to avoid tab-switch spikes
    const elapsed = this.clock.getElapsedTime();

    this._trackFps(delta);

    // Broadcast tick before render so physics/animation systems can update
    // transforms first, then the frame is drawn with fresh state.
    bus.emit('render:tick', { delta, elapsed });

    this.renderer.render(this.scene, this.camera);
  }

  _trackFps(delta){
    this._frameCount++;
    this._fpsTimer += delta;
    if (this._fpsTimer >= 0.5){
      this.fps = Math.round(this._frameCount / this._fpsTimer);
      this._frameCount = 0;
      this._fpsTimer = 0;
      bus.emit('render:fps', this.fps);
    }
  }
}
