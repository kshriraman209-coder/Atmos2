import { bus } from './EventBus.js';
import { MODES } from '../data/config.js';
import { Renderer } from './Renderer.js';
import { Earth } from '../systems/Earth.js';
import { Atmosphere } from '../systems/Atmosphere.js';
import { Sun } from '../systems/Sun.js';
import { Stars } from '../systems/Stars.js';
import { Planets } from '../systems/Planets.js';
import { Refraction } from '../systems/Refraction.js';
import { Twinkling } from '../systems/Twinkling.js';
import { Sunrise } from '../systems/Sunrise.js';
import { Sunset } from '../systems/Sunset.js';
import { ControlPanel } from '../ui/ControlPanel.js';
import { CameraController } from '../systems/CameraController.js';
import { AudioEngine } from '../systems/AudioEngine.js';
import { Quiz } from '../ui/Quiz.js';
import { Challenge } from '../ui/Challenge.js';
import { SaveManager } from '../systems/SaveManager.js';
import { PerformanceMonitor } from '../systems/PerformanceMonitor.js';
import { LearnMode } from '../ui/LearnMode.js';
import { Achievements } from '../systems/Achievements.js';

const MODE_LABELS = {
  learn: 'Learn',
  simulate: 'Simulate',
  explore: 'Explore',
  challenge: 'Challenge',
  quiz: 'Quiz',
};

export class App {
  constructor(){
    this.currentMode = null;
    this.el = {
      boot: document.getElementById('boot-screen'),
      bootFill: document.getElementById('boot-fill'),
      bootStatus: document.getElementById('boot-status'),
      app: document.getElementById('app'),
      nav: document.getElementById('mode-nav'),
      menu: document.getElementById('main-menu'),
      menuActions: document.getElementById('menu-actions'),
      viewRoot: document.getElementById('view-root'),
      canvas: document.getElementById('scene-canvas'),
    };
    this.renderer = null;
  }

  async boot(steps){
    // steps: [{label, task}] — sequential init tasks with progress feedback
    for (let i = 0; i < steps.length; i++){
      this.el.bootStatus.textContent = steps[i].label;
      this.el.bootFill.style.width = `${Math.round(((i) / steps.length) * 100)}%`;
      await steps[i].task();
    }
    this.el.bootFill.style.width = '100%';
    await new Promise(r => setTimeout(r, 200));
    this.el.boot.classList.add('hidden');
    this.el.app.classList.remove('hidden');
    this._buildNav();
    this._buildMenuActions();

    this.renderer = new Renderer(this.el.canvas);
    this.renderer.start();

    this.earth = new Earth(this.renderer.scene);
    this.atmosphere = new Atmosphere(this.earth.group);
    this.sun = new Sun(this.renderer.scene, { earthGroup: this.earth.group, atmosphere: this.atmosphere });
    this.stars = new Stars(this.renderer.scene);
    this.planets = new Planets(this.renderer.scene);
    this.refraction = new Refraction();
    this.twinkling = new Twinkling(this.stars);
    this.sunrise = new Sunrise(this.renderer.scene);
    this.sunset = new Sunset();
    this.controlPanel = new ControlPanel(this.el.viewRoot);
    this.cameraController = new CameraController(this.renderer);
    this.audio = new AudioEngine();
    this.quiz = new Quiz(this.el.viewRoot);
    this.challenge = new Challenge(this.el.viewRoot);
    this.saveManager = new SaveManager(this.controlPanel);
    this.performanceMonitor = new PerformanceMonitor(this.renderer, this.stars);
    this.learnMode = new LearnMode(this.el.viewRoot);
    this.achievements = new Achievements();

    this._showMenuProgress();

    bus.emit('app:ready');
  }

  _buildNav(){
    this.el.nav.innerHTML = '';
    MODES.forEach(mode => {
      const btn = document.createElement('button');
      btn.textContent = MODE_LABELS[mode];
      btn.dataset.mode = mode;
      btn.addEventListener('click', () => this.setMode(mode));
      this.el.nav.appendChild(btn);
    });
  }

  _buildMenuActions(){
    this.el.menuActions.innerHTML = '';
    const entries = [
      { mode: 'learn', label: 'Start Learning', primary: true },
      { mode: 'explore', label: 'Free Explore', primary: false },
      { mode: 'challenge', label: 'Challenge Mode', primary: false },
      { mode: 'quiz', label: 'Take Quiz', primary: false },
    ];
    entries.forEach(({mode, label, primary}) => {
      const btn = document.createElement('button');
      btn.textContent = label;
      if (primary) btn.classList.add('primary');
      btn.addEventListener('click', () => this.setMode(mode));
      this.el.menuActions.appendChild(btn);
    });
  }

  _showMenuProgress(){
    const el = document.getElementById('menu-progress');
    const { quiz } = this.saveManager.data;
    const { unlocked, total } = this.achievements.getProgress();
    if (quiz.attempts === 0 && unlocked === 0) return;

    const parts = [];
    if (quiz.attempts > 0) parts.push(`Best quiz: ${quiz.bestPct}%`);
    parts.push(`${unlocked}/${total} achievements`);
    el.textContent = parts.join(' \u00b7 ');
    el.classList.remove('hidden');
  }

  setMode(mode){
    if (!MODES.includes(mode) || mode === this.currentMode) return;
    this.currentMode = mode;
    this.el.menu.classList.add('hidden');
    this.el.viewRoot.classList.add('active');
    [...this.el.nav.children].forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
    bus.emit('mode:changed', mode);
  }

  showMenu(){
    this.currentMode = null;
    this.el.menu.classList.remove('hidden');
    this.el.viewRoot.classList.remove('active');
    [...this.el.nav.children].forEach(b => b.classList.remove('active'));
  }
}
