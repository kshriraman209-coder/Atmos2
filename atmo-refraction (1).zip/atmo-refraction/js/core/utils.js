// Reusable helpers — physics/render modules import from here to avoid duplication.

export const deg2rad = d => d * Math.PI / 180;
export const rad2deg = r => r * 180 / Math.PI;
export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
export const lerp = (a, b, t) => a + (b - a) * t;

export function arcminToDeg(m){ return m / 60; }

export function formatDegrees(deg, decimals = 2){
  return `${deg.toFixed(decimals)}°`;
}

export function formatArcmin(deg, decimals = 1){
  return `${(deg * 60).toFixed(decimals)}′`;
}

export function formatDuration(minutes){
  const m = Math.round(minutes);
  return m < 60 ? `${m} min` : `${(m/60).toFixed(1)} hr`;
}

// Simple seeded pseudo-random for reproducible star fields
export function makeRng(seed = 1){
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function(){
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}
